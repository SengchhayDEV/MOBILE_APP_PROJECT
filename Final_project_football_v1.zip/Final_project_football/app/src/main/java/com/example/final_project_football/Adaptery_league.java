package com.example.final_project_football;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.List;

public class Adaptery_league extends RecyclerView.Adapter<Adaptery_league.MyViewHolder> {

    private Context fcontext1;
    private List<FootballLeagueClass> fData1;

    public Adaptery_league(Context fcontext1, List<FootballLeagueClass> fData1) {
        this.fcontext1 = fcontext1;
        this.fData1 = fData1;
    }

    @NonNull
    @Override
    public Adaptery_league.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        LayoutInflater inflater = LayoutInflater.from(fcontext1);
        v = inflater.inflate(R.layout.football_league_item, parent, false);

        return new Adaptery_league.MyViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull Adaptery_league.MyViewHolder holder, int position) {

        holder.idLeague.setText(fData1.get(position).getIdLeague());
        holder.strLeague.setText(fData1.get(position).getStrLeague());
        holder.strsport.setText(fData1.get(position).getStrSport());
        holder.leagueA.setText(fData1.get(position).getStrLeagueA());

    }

    @Override
    public int getItemCount() {
        return fData1.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView strLeague;
        TextView idLeague;
        TextView strsport;
        TextView leagueA;

        public MyViewHolder (@NonNull View itemView) {
            super(itemView);

            idLeague = itemView.findViewById(R.id.txt_id_league);
            strLeague = itemView.findViewById(R.id.txt_name_league);
            strsport = itemView.findViewById(R.id.txt_sport_league);
            leagueA = itemView.findViewById(R.id.txt_leagueA);
        }
    }
}
