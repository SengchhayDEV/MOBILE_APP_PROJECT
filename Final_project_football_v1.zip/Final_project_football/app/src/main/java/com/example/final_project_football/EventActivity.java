package com.example.final_project_football;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class EventActivity extends AppCompatActivity {

    private String JSONURL = "https://www.thesportsdb.com/api/v1/json/2/eventslast.php?id=133602";

    List<FootballEventClass> eventlist;
    RecyclerView recyclerView3;

    Button b1,b2,b3,b4,b6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        b1 = findViewById(R.id.btn_1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EventActivity.this, LeagueActivity.class);
                startActivity(intent);
            }
        });
        b2 = findViewById(R.id.btn_2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EventActivity.this, ClubActivity.class);
                startActivity(intent);
            }
        });
        b3 = findViewById(R.id.btn_3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EventActivity.this, PlayerActivity.class);
                startActivity(intent);
            }
        });
        b4 = findViewById(R.id.btn_4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EventActivity.this, EventActivity.class);
                startActivity(intent);
            }
        });
        b6 = findViewById(R.id.btn_6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EventActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        eventlist = new ArrayList<>();
        recyclerView3 = findViewById(R.id.recyclerView_event);


        EventActivity.GetData3 getdata3 = new EventActivity.GetData3();
        getdata3.execute();
    }
    public class GetData3 extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            String current3 = "";

            try {
                URL url;
                HttpURLConnection urlConnection = null;
                try {
                    url = new URL(JSONURL);

                    urlConnection = (HttpURLConnection) url.openConnection();

                    InputStream is3 = urlConnection.getInputStream();
                    InputStreamReader isr3 = new InputStreamReader(is3);

                    int data3 = isr3.read();
                    while (data3 != -1) {
                        current3 += (char) data3;
                        data3 = isr3.read();
                    }
                    return current3;

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }

            return current3;
        }

        @Override
        protected void onPostExecute(String s) {

            try {
                JSONObject jsonObject = new JSONObject(s);
                JSONArray jsonArray = jsonObject.getJSONArray("results");

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject4 = jsonArray.getJSONObject(i);
                    FootballEventClass event = new FootballEventClass();

                    event.setEvent(jsonObject4.getString("strEvent"));
                    event.setSport(jsonObject4.getString("strSport"));
                    event.setLeague_event(jsonObject4.getString("strLeague"));
                    event.setSeason(jsonObject4.getString("strSeason"));
                    event.setDescription_event(jsonObject4.getString("strDescriptionEN"));
                    event.setDate(jsonObject4.getString("dateEvent"));
                    event.setImg_event(jsonObject4.getString("strPoster"));
                    eventlist.add(event);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            PutDataIntoRecyclerView(eventlist);
        }

    }
    private void PutDataIntoRecyclerView(List<FootballEventClass> eventlist) {
        Adaptery_event adaptery = new Adaptery_event(this, eventlist);
        recyclerView3.setLayoutManager(new LinearLayoutManager(this));
        recyclerView3.setAdapter(adaptery);
    }
}