package com.example.waterdeliveryapp;

public class User {

    public String username;
    public String password;
    public String phonenumber;
    public String email;

    public User(){

    }

    public User(String username, String password, String phonenumber, String email){
        this.username = username;
        this.password = password;
        this.phonenumber = phonenumber;
        this.email = email;

    }
}
