package com.example.final_project_football;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        TextView title = findViewById(R.id.toolbar_title);
        title.setText("SETTING");
    }

    public void onclickAbout(View view) {
        About(this);
    }

    public static void About(Activity activity) {
        //initialize alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        //set title
        builder.setTitle("About");
        //set message
        builder.setMessage("This SPORT APP is 1 of 8 final project\nfor 3rd Generation of ITC-GTR\nAcademic Year 2021-2022\nBuilt by JAVA Language");

        builder.show();
    }
    public void onclickRate(View view) {
        Rate(this);
    }
    public static void Rate(Activity activity) {
        //initialize alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        //set title
        builder.setTitle("Rating");
        //set message
        builder.setMessage("Thanks for Rate Us");

        builder.show();
    }
    public void onclickVersion(View view) {
        Version(this);
    }
    public static void Version(Activity activity) {
        //initialize alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        //set title
        builder.setTitle("v.1.0.3");
        //set message
        builder.setMessage("This is the Latest Version of App");

        builder.show();
    }
    public void onclickLogout(View view){
        //log out
        logout(this);
    }

    public static void logout(Activity activity) {
        //initialize alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        //set title
        builder.setTitle("log out");
        //set message
        builder.setMessage("Are you sure you want to logout");
        //positive yes button
        builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //Finish Activity
                activity.finishAffinity();
                //exit app
                System.exit(0);
            }
        });
        //Negative no button
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //Dismiss dialog
                dialogInterface.dismiss();
            }
        });
        //show dialog
        builder.show();
    }
    public void onclickFacebook(View view){
        gotUri("https://www.facebook.com/");
    }
    public void onclickTwitter(View view){
        gotUri("https://twitter.com/i/flow/login");
    }
    public void gotUri(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }
}