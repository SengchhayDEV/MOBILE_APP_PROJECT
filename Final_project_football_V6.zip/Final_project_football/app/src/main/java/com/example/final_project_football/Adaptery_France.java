package com.example.final_project_football;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class Adaptery_France extends RecyclerView.Adapter<Adaptery_France.MyViewHolder> {
    private Context frcontext;
    private List<FootballFranceClass> frData;

    public Adaptery_France(Context frcontext, List<FootballFranceClass> frData) {
        this.frcontext = frcontext;
        this.frData = frData;
    }

    @NonNull
    @Override
    public Adaptery_France.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        LayoutInflater inflater = LayoutInflater.from(frcontext);
        v = inflater.inflate(R.layout.football_item, parent, false);

        return new MyViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull Adaptery_France.MyViewHolder holder, int position2) {

        holder.idLeague.setText(frData.get(position2).getIdLeague());
        holder.strLeague.setText(frData.get(position2).getStrLeague());
        holder.strsport.setText(frData.get(position2).getStrSport());
        holder.leagueA.setText(frData.get(position2).getStrLeagueAlternate());
        holder.description.setText(frData.get(position2).getStrDescriptionEN());
        holder.youtube.setText(frData.get(position2).getYoutube());

        //load image
        Glide.with(frcontext)
                .load(frData.get(position2).getStrBadge())
                .into(holder.strBadge);

    }

    @Override
    public int getItemCount() {
        return frData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView strLeague;
        TextView idLeague;
        TextView strsport;
        TextView leagueA;
        TextView description;
        TextView youtube;
        ImageView strBadge;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            idLeague = itemView.findViewById(R.id.txt_id);
            strLeague = itemView.findViewById(R.id.txt_name);
            strBadge = itemView.findViewById(R.id.img);
            strsport = itemView.findViewById(R.id.txt_sport);
            leagueA = itemView.findViewById(R.id.txt_club);
            description = itemView.findViewById(R.id.txt_description);
            youtube = itemView.findViewById(R.id.txt_youtube);
        }
    }
}
