package com.example.final_project_football;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class Adaptery extends RecyclerView.Adapter<Adaptery.MyViewHolder> {

    private Context fcontext;
    private List<FootballModelClass> fData;

    public Adaptery(Context fcontext, List<FootballModelClass> fData) {
        this.fcontext = fcontext;
        this.fData = fData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        LayoutInflater inflater = LayoutInflater.from(fcontext);
        v = inflater.inflate(R.layout.football_item, parent, false);

        return new MyViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.idLeague.setText(fData.get(position).getIdLeague());
        holder.strLeague.setText(fData.get(position).getStrLeague());
        holder.strsport.setText(fData.get(position).getStrSport());
        holder.leagueA.setText(fData.get(position).getStrLeagueAlternate());
        holder.description.setText(fData.get(position).getStrDescriptionEN());
        holder.youtube.setText(fData.get(position).getYoutube());

        //load image
        Glide.with(fcontext)
                .load(fData.get(position).getStrBadge())
                .into(holder.strBadge);

    }

    @Override
    public int getItemCount() {
        return fData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView strLeague;
        TextView idLeague;
        TextView strsport;
        TextView leagueA;
        TextView description;
        TextView youtube;
        ImageView strBadge;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            idLeague = itemView.findViewById(R.id.txt_id);
            strLeague = itemView.findViewById(R.id.txt_name);
            strBadge = itemView.findViewById(R.id.img);
            strsport = itemView.findViewById(R.id.txt_sport);
            leagueA = itemView.findViewById(R.id.txt_club);
            description = itemView.findViewById(R.id.txt_description);
            youtube = itemView.findViewById(R.id.txt_youtube);
        }
    }
}
