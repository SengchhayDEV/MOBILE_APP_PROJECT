package com.example.final_project_football;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class Adaptery_club extends RecyclerView.Adapter<Adaptery_club.MyViewHolder> {

    private Context fcontext2;
    private List<FootballClubClass> fData2;

    public Adaptery_club(Context fcontext2, List<FootballClubClass> fData2) {
        this.fcontext2 = fcontext2;
        this.fData2 = fData2;
    }
    @NonNull
    @Override
    public Adaptery_club.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        LayoutInflater inflater = LayoutInflater.from(fcontext2);
        v = inflater.inflate(R.layout.football_club_item, parent, false);

        return new Adaptery_club.MyViewHolder(v);
    }
    @Override
    public void onBindViewHolder(@NonNull Adaptery_club.MyViewHolder holder, int position) {

        holder.id.setText(fData2.get(position).getId());
        holder.rank.setText(fData2.get(position).getRank());
        holder.team.setText(fData2.get(position).getTeam());
        holder.league.setText(fData2.get(position).getLeague());
        holder.description.setText(fData2.get(position).getDescription());

        Glide.with(fcontext2)
                .load(fData2.get(position).getImg_club())
                .into(holder.img_club);

    }
    @Override
    public int getItemCount() {
        return fData2.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView id;
        TextView rank;
        TextView team;
        TextView league;
        TextView description;
        ImageView img_club;

        public MyViewHolder (@NonNull View itemView) {
            super(itemView);

            id = itemView.findViewById(R.id.txt_id_club);
            rank = itemView.findViewById(R.id.txt_rank_club);
            team = itemView.findViewById(R.id.txt_team_club);
            league = itemView.findViewById(R.id.txt_club_league);
            description = itemView.findViewById(R.id.txt_description_club);
            img_club = itemView.findViewById(R.id.img_club);
        }
    }
}
