package com.example.final_project_football;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class PlayerActivity extends AppCompatActivity {

    private String JSONURL = "https://www.thesportsdb.com/api/v1/json/2/searchplayers.php?p=Danny%20Welbeck";

    List<FootballPlayerClass> playerlist;
    RecyclerView recyclerView4;

    Button b1,b2,b3,b4,b6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        b1 = findViewById(R.id.btn_1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PlayerActivity.this, LeagueActivity.class);
                startActivity(intent);
            }
        });
        b2 = findViewById(R.id.btn_2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PlayerActivity.this, ClubActivity.class);
                startActivity(intent);
            }
        });
        b3 = findViewById(R.id.btn_3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PlayerActivity.this, PlayerActivity.class);
                startActivity(intent);
            }
        });
        b4 = findViewById(R.id.btn_4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PlayerActivity.this, EventActivity.class);
                startActivity(intent);
            }
        });
        b6 = findViewById(R.id.btn_6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PlayerActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        playerlist = new ArrayList<>();
        recyclerView4 = findViewById(R.id.recyclerView_player);


        PlayerActivity.GetData4 getdata4 = new PlayerActivity.GetData4();
        getdata4.execute();
    }
    public class GetData4 extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            String current4 = "";

            try {
                URL url;
                HttpURLConnection urlConnection = null;
                try {
                    url = new URL(JSONURL);

                    urlConnection = (HttpURLConnection) url.openConnection();

                    InputStream is4 = urlConnection.getInputStream();
                    InputStreamReader isr4 = new InputStreamReader(is4);

                    int data4 = isr4.read();
                    while (data4 != -1) {
                        current4 += (char) data4;
                        data4 = isr4.read();
                    }
                    return current4;

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }

            return current4;
        }

        @Override
        protected void onPostExecute(String s) {

            try {
                JSONObject jsonObject = new JSONObject(s);
                JSONArray jsonArray = jsonObject.getJSONArray("player");

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject5 = jsonArray.getJSONObject(i);
                    FootballPlayerClass player = new FootballPlayerClass();

                    player.setName(jsonObject5.getString("strPlayer"));
                    player.setNationality(jsonObject5.getString("strNationality"));
                    player.setAge(jsonObject5.getString("idSoccerXML"));
                    player.setClub(jsonObject5.getString("strTeam"));
                    player.setBirthdate(jsonObject5.getString("dateBorn"));
                    player.setWage(jsonObject5.getString("strWage"));
                    player.setDescription_player(jsonObject5.getString("strDescriptionEN"));
                    player.setRender(jsonObject5.getString("strRender"));
                    playerlist.add(player);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            PutDataIntoRecyclerView(playerlist);
        }

    }
    private void PutDataIntoRecyclerView(List<FootballPlayerClass> playerlist) {
        Adaptery_player adaptery = new Adaptery_player(this, playerlist);
        recyclerView4.setLayoutManager(new LinearLayoutManager(this));
        recyclerView4.setAdapter(adaptery);
    }
}