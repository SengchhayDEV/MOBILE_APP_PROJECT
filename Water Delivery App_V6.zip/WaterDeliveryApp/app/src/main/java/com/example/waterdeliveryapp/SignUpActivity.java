package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    EditText edittextusername;
    EditText edittextpassword;
    EditText edittextphonenumber;
    EditText edittextemail;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //hide navigation bar
        //getSupportActionBar().hide();

        edittextusername = (EditText) findViewById(R.id.name);
        edittextpassword = (EditText) findViewById(R.id.password);
        edittextphonenumber = (EditText) findViewById(R.id.numberphone);
        edittextemail = (EditText) findViewById(R.id.email);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
    }
    public void signupclick(View v) {

        String txtusername = edittextusername.getText().toString().trim();
        String txtpassword = edittextpassword.getText().toString().trim();
        String txtphonenumber = edittextphonenumber.getText().toString().trim();
        String txtemail = edittextemail.getText().toString().trim();

        if (txtusername.isEmpty()){
            edittextusername.setError("Please enter username");
            edittextusername.requestFocus();
        }
        if (txtpassword.isEmpty() || txtpassword.length() < 6 ){
            edittextpassword.setError(("Please enter password al least 6-digits"));
            edittextpassword.requestFocus();
        }
        if (txtphonenumber.isEmpty()){
            edittextphonenumber.setError(("Please enter phonenumber"));
            edittextphonenumber.requestFocus();
        }
        if (txtemail.isEmpty()){
            edittextemail.setError(("Please enter Email"));
            edittextemail.requestFocus();
        }

        progressBar.setVisibility(View.VISIBLE);

        mAuth.createUserWithEmailAndPassword(txtemail, txtpassword)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {

                            User user = new User(txtusername, txtpassword, txtphonenumber, txtemail);

                            FirebaseDatabase.getInstance("https://water-delivery-app-2faf9-default-rtdb.firebaseio.com/").getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(SignUpActivity.this, "Register Successful", Toast.LENGTH_LONG).show();
                                        progressBar.setVisibility(View.GONE);
                                    }
                                    else {
                                        Toast.makeText(SignUpActivity.this, "Register Failed", Toast.LENGTH_LONG).show();
                                        progressBar.setVisibility(View.GONE);
                                    }
                                }
                            });

                        }
                        else {
                            Toast.makeText(SignUpActivity.this, "Register Failed", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
    }
}