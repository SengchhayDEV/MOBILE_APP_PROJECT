package com.example.final_project_football;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4,b5,b6;
    ProgressDialog dialog;

    private static String JSONURL = "https://www.thesportsdb.com/api/v1/json/2/search_all_leagues.php?c=England&s=Soccer";

    List<FootballModelClass> footballlist;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dialog = new ProgressDialog(this);
        dialog.setTitle("Loading... Please wait");
        dialog.show();

        ImageView righticon = findViewById(R.id.right_icon);

        righticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(intent);
            }
        });

        b1 = findViewById(R.id.btn_1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LeagueActivity.class);
                startActivity(intent);
            }
        });
        b2 = findViewById(R.id.btn_2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ClubActivity.class);
                startActivity(intent);
            }
        });
        b3 = findViewById(R.id.btn_3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
                startActivity(intent);
            }
        });
        b4 = findViewById(R.id.btn_4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EventActivity.class);
                startActivity(intent);
            }
        });
        b5 = findViewById(R.id.btn_5);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, France_league_Activity.class);
                startActivity(intent);
            }
        });
        b6 = findViewById(R.id.btn_6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        footballlist = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView);


        GetData getdata = new GetData();
        getdata.execute();
    }

    public class GetData extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... strings) {

            String current = "";

            try {
                URL url;
                HttpURLConnection urlConnection = null;
                try {
                        url = new URL (JSONURL);

                        urlConnection = (HttpURLConnection) url.openConnection();

                        InputStream is = urlConnection.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is);

                        int data = isr.read();
                        while ( data != -1){
                            current += (char)data;
                            data = isr.read();
                        }
                        return current;

                    }
                    catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                    finally {
                        if(urlConnection != null){
                            urlConnection.disconnect();
                        }
                    }
            } catch (Exception exception) {
                exception.printStackTrace();
            }

            return current;
        }

        @Override
        protected void onPostExecute(String s) {

            try {
                JSONObject jsonObject = new JSONObject(s);
                JSONArray jsonArray = jsonObject.getJSONArray("countries");

                for (int i = 0 ; i < jsonArray.length(); i ++){
                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                    FootballModelClass model = new FootballModelClass();

                    model.setIdLeague(jsonObject1.getString("idLeague"));
                    model.setStrLeague(jsonObject1.getString("strLeague"));
                    model.setStrBadge(jsonObject1.getString("strBadge"));
                    model.setStrSport(jsonObject1.getString("strSport"));
                    model.setStrLeagueAlternate(jsonObject1.getString("strLeagueAlternate"));
                    model.setStrDescriptionEN(jsonObject1.getString("strDescriptionEN"));
                    model.setYoutube(jsonObject1.getString("strWebsite"));

                    footballlist.add(model);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            PutDataIntoRecyclerView(footballlist);
        }
    }
    private void PutDataIntoRecyclerView(List<FootballModelClass> footballlist){
        Adaptery adaptery = new Adaptery(this, footballlist);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adaptery);
    }
    public void onclickStar(View view){
        Toast.makeText(this, "You add this League into Favourite list", Toast.LENGTH_SHORT).show();
        ImageView image = findViewById(R.id.img_star);
        image.setVisibility(View.GONE);
    }

}