package com.example.newsapp;

import com.example.newsapp.model.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);
}
