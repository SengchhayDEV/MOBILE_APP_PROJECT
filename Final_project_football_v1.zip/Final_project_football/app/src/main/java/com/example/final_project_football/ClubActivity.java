package com.example.final_project_football;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ClubActivity extends AppCompatActivity {

    private String JSONURL = "https://www.thesportsdb.com/api/v1/json/2/lookuptable.php?l=4328&s=2020-2021";

    List<FootballClubClass> clublist;
    RecyclerView recyclerView2;

    Button b1,b2,b3,b4,b6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club);

        b1 = findViewById(R.id.btn_1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClubActivity.this, LeagueActivity.class);
                startActivity(intent);
            }
        });
        b2 = findViewById(R.id.btn_2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClubActivity.this, ClubActivity.class);
                startActivity(intent);
            }
        });
        b3 = findViewById(R.id.btn_3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClubActivity.this, PlayerActivity.class);
                startActivity(intent);
            }
        });
        b4 = findViewById(R.id.btn_4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClubActivity.this, EventActivity.class);
                startActivity(intent);
            }
        });
        b6 = findViewById(R.id.btn_6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClubActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        clublist = new ArrayList<>();
        recyclerView2 = findViewById(R.id.recyclerView_club);


        ClubActivity.GetData2 getdata2 = new ClubActivity.GetData2();
        getdata2.execute();
    }

    public class GetData2 extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            String current2 = "";

            try {
                URL url;
                HttpURLConnection urlConnection = null;
                try {
                    url = new URL(JSONURL);

                    urlConnection = (HttpURLConnection) url.openConnection();

                    InputStream is2 = urlConnection.getInputStream();
                    InputStreamReader isr2 = new InputStreamReader(is2);

                    int data2 = isr2.read();
                    while (data2 != -1) {
                        current2 += (char) data2;
                        data2 = isr2.read();
                    }
                    return current2;

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }

            return current2;
        }

        @Override
        protected void onPostExecute(String s) {

            try {
                JSONObject jsonObject = new JSONObject(s);
                JSONArray jsonArray = jsonObject.getJSONArray("table");

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject3 = jsonArray.getJSONObject(i);
                    FootballClubClass club = new FootballClubClass();

                    club.setId(jsonObject3.getString("idStanding"));
                    club.setRank(jsonObject3.getString("intRank"));
                    club.setTeam(jsonObject3.getString("strTeam"));
                    club.setLeague(jsonObject3.getString("strLeague"));
                    club.setDescription(jsonObject3.getString("strDescription"));
                    club.setImg_club(jsonObject3.getString("strTeamBadge"));
                    clublist.add(club);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            PutDataIntoRecyclerView(clublist);
        }

    }
    private void PutDataIntoRecyclerView(List<FootballClubClass> clublist) {
        Adaptery_club adaptery = new Adaptery_club(this, clublist);
        recyclerView2.setLayoutManager(new LinearLayoutManager(this));
        recyclerView2.setAdapter(adaptery);
    }
}