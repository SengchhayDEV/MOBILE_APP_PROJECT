package com.example.final_project_football;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class Adaptery_player extends RecyclerView.Adapter<Adaptery_player.MyViewHolder> {

    private Context fcontext4;
    private List<FootballPlayerClass> fData4;

    public Adaptery_player(Context fcontext4, List<FootballPlayerClass> fData4) {
        this.fcontext4 = fcontext4;
        this.fData4 = fData4;
    }

    @NonNull
    @Override
    public Adaptery_player.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        LayoutInflater inflater = LayoutInflater.from(fcontext4);
        v = inflater.inflate(R.layout.player_info, parent, false);

        return new Adaptery_player.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptery_player.MyViewHolder holder, int position) {

        holder.name.setText(fData4.get(position).getName());
        holder.nationality.setText(fData4.get(position).getNationality());
        holder.age.setText(fData4.get(position).getAge());
        holder.birthdate.setText(fData4.get(position).getBirthdate());
        holder.club.setText(fData4.get(position).getClub());
        holder.wage.setText(fData4.get(position).getWage());
        holder.description.setText(fData4.get(position).getDescription_player());
        Glide.with(fcontext4)
                .load(fData4.get(position).getRender())
                .into(holder.render);

    }

    @Override
    public int getItemCount() {
        return fData4.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView name;
        TextView nationality;
        TextView age;
        TextView birthdate;
        TextView club;
        TextView wage;
        TextView description;
        ImageView render;

        public MyViewHolder (@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.txt_player_name);
            nationality = itemView.findViewById(R.id.txt_player_nationality);
            age = itemView.findViewById(R.id.txt_player_age);
            birthdate = itemView.findViewById(R.id.txt_player_birthdate);
            club = itemView.findViewById(R.id.txt_player_club);
            wage = itemView.findViewById(R.id.txt_player_wage);
            description = itemView.findViewById(R.id.txt_player_description);
            render = itemView.findViewById(R.id.img_render);
        }
    }
}
