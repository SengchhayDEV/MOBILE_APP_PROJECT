package com.example.final_project_football;

public class FootballFranceClass {
    String strLeague;
    String idLeague;
    String strBadge;
    String strSport;
    String strLeagueAlternate;
    String strDescriptionEN;
    String youtube;

    public FootballFranceClass(String strLeague, String idLeague, String strBadge, String strSport, String strLeagueAlternate, String strDescriptionEN){
        this.strLeague = strLeague;
        this.idLeague = idLeague;
        this.strBadge = strBadge;
        this.strSport = strSport;
        this.strLeagueAlternate = strLeagueAlternate;
        this.strDescriptionEN = strDescriptionEN;
        this.youtube = youtube;
    }

    public FootballFranceClass(){
    }

    public String getStrLeague() {
        return strLeague;
    }

    public void setStrLeague(String strLeague) {
        this.strLeague = strLeague;
    }

    public String getIdLeague() {
        return idLeague;
    }

    public void setIdLeague(String idLeague) {
        this.idLeague = idLeague;
    }

    public String getStrBadge() {
        return strBadge;
    }

    public void setStrBadge(String strBadge) {
        this.strBadge = strBadge;
    }

    public String getStrSport() {
        return strSport;
    }

    public void setStrSport(String strSport) {
        this.strSport = strSport;
    }

    public String getStrLeagueAlternate() {
        return strLeagueAlternate;
    }

    public void setStrLeagueAlternate(String strLeagueAlternate) {
        this.strLeagueAlternate = strLeagueAlternate;
    }

    public String getStrDescriptionEN() {
        return strDescriptionEN;
    }

    public void setStrDescriptionEN(String strDescriptionEN) {
        this.strDescriptionEN = strDescriptionEN;
    }

    public String getYoutube() {
        return youtube;
    }

    public void setYoutube(String youtube) {
        this.youtube = youtube;
    }
}

