package com.example.final_project_football;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class Adaptery_event extends RecyclerView.Adapter<Adaptery_event.MyViewHolder> {

    private Context fcontext3;
    private List<FootballEventClass> fData3;

    public Adaptery_event(Context fcontext3, List<FootballEventClass> fData3) {
        this.fcontext3 = fcontext3;
        this.fData3 = fData3;
    }

    @NonNull
    @Override
    public Adaptery_event.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        LayoutInflater inflater = LayoutInflater.from(fcontext3);
        v = inflater.inflate(R.layout.new_event_item, parent, false);

        return new Adaptery_event.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptery_event.MyViewHolder holder, int position) {

        holder.event.setText(fData3.get(position).getEvent());
        holder.sport_event.setText(fData3.get(position).getSport());
        holder.league_event.setText(fData3.get(position).getLeague_event());
        holder.season.setText(fData3.get(position).getSeason());
        holder.description_event.setText(fData3.get(position).getDescription_event());
        holder.date_event.setText(fData3.get(position).getDate());

        Glide.with(fcontext3)
                .load(fData3.get(position).getImg_event())
                .into(holder.img_poster);

    }

    @Override
    public int getItemCount() {
        return fData3.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView event;
        TextView sport_event;
        TextView league_event;
        TextView season;
        TextView description_event;
        TextView date_event;
        ImageView img_poster;

        public MyViewHolder (@NonNull View itemView) {
            super(itemView);

            event = itemView.findViewById(R.id.txt_event);
            sport_event = itemView.findViewById(R.id.txt_sport_event);
            league_event = itemView.findViewById(R.id.txt_league_event);
            season = itemView.findViewById(R.id.txt_season);
            description_event = itemView.findViewById(R.id.txt_description_event);
            date_event = itemView.findViewById(R.id.txt_date_event);
            img_poster = itemView.findViewById(R.id.img_poster);
        }
    }
}
