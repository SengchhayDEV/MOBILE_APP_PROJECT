package com.example.final_project_football;

public class FootballPlayerClass {

    String name;
    String nationality;
    String age;
    String birthdate;
    String club;
    String wage;
    String description_player;
    String render;

    public FootballPlayerClass(){
        this.name = name;
        this.nationality = nationality;
        this.age = age;
        this.birthdate = birthdate;
        this.club = club;
        this.wage = wage;
        this.description_player = description_player;
        this.render = render;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getClub() {
        return club;
    }

    public void setClub(String club) {
        this.club = club;
    }

    public String getWage() {
        return wage;
    }

    public void setWage(String wage) {
        this.wage = wage;
    }

    public String getDescription_player() {
        return description_player;
    }

    public void setDescription_player(String description_player) {
        this.description_player = description_player;
    }

    public String getRender() {
        return render;
    }

    public void setRender(String render) {
        this.render = render;
    }
}
