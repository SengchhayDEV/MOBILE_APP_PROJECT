package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignInActivity extends AppCompatActivity {

    EditText editTextusername, editTextpassword;
    TextView textViewforgotpassword, textViewregister;

    ProgressBar progressBar;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        //hide navigation bar
        //getSupportActionBar().hide();

        editTextusername = findViewById(R.id.editTextsigninusername);
        editTextpassword = findViewById(R.id.editTextsigninpassword);

        textViewforgotpassword = findViewById(R.id.txtforgotpw);
        textViewregister = findViewById(R.id.txtregister);

        progressBar = findViewById(R.id.progressBar2);

        mAuth = FirebaseAuth.getInstance();
    }
    public void txtforgotpasswordClicked (View v){
        Intent intent = new Intent(SignInActivity.this, ForgotPasswordActivity.class);
        startActivity(intent);

    }
    public void txtRegisterClicked (View v){
        Intent intent = new Intent(SignInActivity.this, SignUpActivity.class);
        startActivity(intent);

    }
    public void buttonsigninClick (View v){

        String username = editTextusername.getText().toString().trim();
        String password = editTextpassword.getText().toString().trim();

        if (!Patterns.EMAIL_ADDRESS.matcher(username).matches()){
            editTextusername.setError("Please enter a valid email");
            editTextusername.requestFocus();
        }
        if (editTextpassword.length() < 6){
            editTextpassword.setError(("Please enter password atleast 6-digits"));
            editTextpassword.requestFocus();
        }

        progressBar.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(username, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Toast.makeText(SignInActivity.this, "Sign in Successful", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                    startActivity(new Intent(SignInActivity.this, DashboardActivity.class));
                }
                else {
                    Toast.makeText(SignInActivity.this, "Sign in failed", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
    }
}