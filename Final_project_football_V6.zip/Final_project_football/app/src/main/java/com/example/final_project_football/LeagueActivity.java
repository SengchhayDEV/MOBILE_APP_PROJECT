package com.example.final_project_football;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class LeagueActivity extends AppCompatActivity {

    ProgressDialog dialog;

    private String JSONURL = "https://www.thesportsdb.com/api/v1/json/2/all_leagues.php";

    List<FootballLeagueClass> footballlist1;
    RecyclerView recyclerView1;

    Button b1,b2,b3,b4,b5,b6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_league);

        dialog = new ProgressDialog(this);
        dialog.setTitle("Loading... Please wait");
        dialog.show();

        ImageView righticon = findViewById(R.id.right_icon);

        righticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LeagueActivity.this, SettingActivity.class);
                startActivity(intent);
            }
        });

        b1 = findViewById(R.id.btn_1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LeagueActivity.this, LeagueActivity.class);
                startActivity(intent);
            }
        });
        b2 = findViewById(R.id.btn_2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LeagueActivity.this, ClubActivity.class);
                startActivity(intent);
            }
        });
        b3 = findViewById(R.id.btn_3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LeagueActivity.this, PlayerActivity.class);
                startActivity(intent);
            }
        });
        b4 = findViewById(R.id.btn_4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LeagueActivity.this, EventActivity.class);
                startActivity(intent);
            }
        });
        b5 = findViewById(R.id.btn_5);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LeagueActivity.this, France_league_Activity.class);
                startActivity(intent);
            }
        });
        b6 = findViewById(R.id.btn_6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LeagueActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        footballlist1 = new ArrayList<>();
        recyclerView1 = findViewById(R.id.recyclerView_league);


        LeagueActivity.GetData1 getdata1 = new LeagueActivity.GetData1();
        getdata1.execute();
    }

    public class GetData1 extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            String current1 = "";

            try {
                URL url;
                HttpURLConnection urlConnection = null;
                try {
                    url = new URL(JSONURL);

                    urlConnection = (HttpURLConnection) url.openConnection();

                    InputStream is1 = urlConnection.getInputStream();
                    InputStreamReader isr1 = new InputStreamReader(is1);

                    int data1 = isr1.read();
                    while (data1 != -1) {
                        current1 += (char) data1;
                        data1 = isr1.read();
                    }
                    return current1;

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }

            return current1;
        }

        @Override
        protected void onPostExecute(String s) {

            try {
                JSONObject jsonObject = new JSONObject(s);
                JSONArray jsonArray = jsonObject.getJSONArray("leagues");

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject2 = jsonArray.getJSONObject(i);
                    FootballLeagueClass model1 = new FootballLeagueClass();

                    model1.setIdLeague(jsonObject2.getString("idLeague"));
                    model1.setStrLeague(jsonObject2.getString("strLeague"));
                    model1.setStrSport(jsonObject2.getString("strSport"));
                    model1.setStrLeagueA(jsonObject2.getString("strLeagueAlternate"));

                    footballlist1.add(model1);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            PutDataIntoRecyclerView(footballlist1);
        }

    }

    private void PutDataIntoRecyclerView(List<FootballLeagueClass> footballlist1) {
        Adaptery_league adaptery = new Adaptery_league(this, footballlist1);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));
        recyclerView1.setAdapter(adaptery);
    }
    public void onclickStar(View view){
        Toast.makeText(this, "You add this League into Favourite list", Toast.LENGTH_SHORT).show();
        ImageView image = findViewById(R.id.img_star);
        image.setVisibility(View.GONE);
    }
}