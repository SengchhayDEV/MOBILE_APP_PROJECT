package com.example.final_project_football;

public class FootballClubClass {

    String id;
    String rank;
    String team;
    String league;
    String description;
    String img_club;

    public FootballClubClass(){
        this.id = id;
        this.rank = rank;
        this.team = team;
        this.league = league;
        this.description = description;
        this.img_club = img_club;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getLeague() {
        return league;
    }

    public void setLeague(String league) {
        this.league = league;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImg_club() {
        return img_club;
    }

    public void setImg_club(String img_club) {
        this.img_club = img_club;
    }
}
