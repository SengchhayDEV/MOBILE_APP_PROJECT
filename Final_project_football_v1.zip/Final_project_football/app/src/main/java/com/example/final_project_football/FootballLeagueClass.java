package com.example.final_project_football;

public class FootballLeagueClass {

    String idLeague;
    String strLeague;
    String strSport;
    String strLeagueA;

    public FootballLeagueClass(String idLeague, String strLeague, String strSport, String strLeagueA){
        this.idLeague = idLeague;
        this.strLeague = strLeague;
        this.strSport = strSport;
        this.strLeagueA = strLeagueA;

    }

    public FootballLeagueClass(){

    }

    public String getIdLeague() {
        return idLeague;
    }

    public void setIdLeague(String idLeague) {
        this.idLeague = idLeague;
    }

    public String getStrLeague() {
        return strLeague;
    }

    public void setStrLeague(String strLeague) {
        this.strLeague = strLeague;
    }

    public String getStrSport() {
        return strSport;
    }

    public void setStrSport(String strSport) {
        this.strSport = strSport;
    }

    public String getStrLeagueA() {
        return strLeagueA;
    }

    public void setStrLeagueA(String strLeagueA) {
        this.strLeagueA = strLeagueA;
    }
}
